# JSON_mini_project
Springboard: This is the first of many mini-projects that you’ll complete to consolidate your learning and apply the tools you’ve learned. This World Bank dataset from a school quality improvement project in Ethiopia is a good example of a real-life dataset that you’ll encounter as a data scientist. Practice your data wrangling skills on this mini-project before you apply them to your capstone.
iPython workbook is included alongside of necessary data extracts referenced in notebook
